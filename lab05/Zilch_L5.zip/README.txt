CSCI441, Computer Graphics, Fall 2015
Dr. Jeffrey Paone

Code Example: Lab05

	This program is the completed Lab02 Flight Simulator.  This is version
    0.33!  It will add lighting to make our scene look more realistic.

Usage: 
    Pressing 'w' moves the camera forward and pressing 's' moves the camera back.

    Left click and dragging the mouse moves the camera around.

    Ctrl + Left click will zoom the camera in/out from our plane.

    The user can also press the 'q' or ESC key to quit the program.

Compilation Instructions:
    Simply navigate to the directory and type 'make.' main.cpp needs
    to be linked with the OpenGL / freeglut libraries.  

Notes:

Q1: Yea sure

Q2: Less pretty

Q3: better, they're the same color

Q4: Mostly, order given

Q5: Light emanates from the teapot

Q6: Yes

Q7: No

Q8: Yesh

Q9: Yesh

Q10: Yesh

Q11: 7

Q12: just right

Q13: ~1 hour

Q14: Nope

