CSCI441, Computer Graphics, Fall 2015
Dr. Jeffrey Paone

Code Example: Lab04

	This program is the completed Lab02 Flight Simulator.  This is version
    0.32a!  It will add sound and has a little plane that we can follow around.

Usage: 
    Pressing 'w' moves the camera forward and pressing 's' moves the camera back.

    Left click and dragging the mouse moves the camera around.

    Ctrl + Left click will zoom the camera in/out from our plane.

    The user can also press the 'q' or ESC key to quit the program.

Compilation Instructions:
    Simply navigate to the directory and type 'make.' main.cpp needs
    to be linked with the OpenGL / freeglut libraries and the OpenAL / freealut
    libraries.  

Notes:

Q1: Yes

Q2: Yes

Q3: Kinda

Q4: Yes

Q5: No

Q6: not entirely sure

Q7: Yup

Q8: Yup

Q9: Yup

Q10: 7

Q11: just right

Q12: ~1.5 hours

Q13: Nope



